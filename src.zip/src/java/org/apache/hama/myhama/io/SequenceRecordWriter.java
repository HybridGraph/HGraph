package org.apache.hama.myhama.io;

public class SequenceRecordWriter {
    // TODO
}
