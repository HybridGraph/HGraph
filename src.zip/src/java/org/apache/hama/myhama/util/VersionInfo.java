package org.apache.hama.myhama.util;

import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Termite version information.
 * 
 * A version information class.
 * 
 * @author zhigang wang
 * @version 0.1
 */
public class VersionInfo {

    public static String getVersionInfo() {
        return "beta-0.3";
    }
    
    public static String getSourceCodeInfo() {
        return "https://github.com/HybridGraph";
    }
    
    public static String getCompilerInfo() {
        return "wangzhigang@ouc.edu.cn";
    }
    
    public static String getWorkPlaceInfo() {
    	return "Ocean University of China";
    }
    
    public static String getCompilerDateInfo() {
    	SimpleDateFormat df = 
    		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//format
    	return df.format(new Date());//get the current time
    }
}
