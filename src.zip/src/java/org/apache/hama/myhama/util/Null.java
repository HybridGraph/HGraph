package org.apache.hama.myhama.util;

public class Null {

}
