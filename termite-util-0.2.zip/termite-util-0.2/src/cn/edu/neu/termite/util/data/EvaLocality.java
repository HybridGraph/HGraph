package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * Evaluate the locality coefficient for a graph in Termite format.
 * 
 * Termite format: <code>id</code>\t<code>dstId1:dstId2:...</code>
 * 
 * After evalutation, this program reports the following info.:
 * (1) #output vertices;
 * (2) #output edges;
 * (3) #output avg outgoing degree;
 * (4) #locality coefficient;
 * 
 * @author Zhigang Wang
 * @time 2014.04.23
 */
public class EvaLocality {
	
	private static String inFileName = "/termite-rd-pr";
	
	private static File inputFile;
	private static FileReader FR;
	private static BufferedReader BR;
	
	private static int VertexCounter = 0;
	private static long EdgeCounter = 0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length < 1) {
			System.out.println("input arguments of evaluation: <input file>");
			System.exit(-1);
		} else {
			inFileName = args[0];
		}
		
		System.out.println("begin to evaluate locality coefficient, please wait...");
		try {
			inputFile = new File(inFileName);
			FR = new FileReader(inputFile);
			BR = new BufferedReader(FR, 65536);
			
			String context = null;
			String[] firstSplit = null, secondSplit = null;
			int edgeLength = 0;
			double coe = 0;
			while ((context = BR.readLine()) != null) {
				firstSplit = context.split("\t");
				secondSplit = firstSplit[1].split(":");
				edgeLength = secondSplit.length;
				
				coe += compute(secondSplit);
				
				VertexCounter++;
				EdgeCounter += edgeLength;
				if (VertexCounter % 10000 == 0) {
					System.out.println("has pro. " + VertexCounter);
				}
			}
			
			BR.close();
			FR.close();
			System.out.println("evaluate successfully!");
			System.out.println("#vertices=" + VertexCounter);
			System.out.println("#edges=" + EdgeCounter);
			System.out.println("avg outgoing degree=" + EdgeCounter/(float)VertexCounter);
			System.out.println("locality coefficient=" + coe);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static long compute(String[] edges) {
		/*int[] sort = new int[edges.length];
		for (int i = 0; i < edges.length; i++) {
			sort[i] = Integer.valueOf(edges[i]);
		}
		
		for (int i = 0; i < sort.length; i++) {
			for (int j = i + 1; j < sort.length; j++) {
				if (sort[i] > sort[j]) {
					int tmp = sort[j];
					sort[j] = sort[i];
					sort[i] = tmp;
				}
			}
		}
		
		long coe = 0L;
		if (sort.length <= 1) {
			coe = 0L;
		} else {
			for (int i = 1; i < sort.length; i++) {
				coe += (sort[i] - sort[i - 1]);
			}
		}
		
		return coe;*/
		
		long coe = 0L;
		if (edges.length <= 1) {
			coe = 0L;
		} else {
			for (int i = 1; i < edges.length; i++) {
				coe += (Integer.valueOf(edges[i]) - Integer.valueOf(edges[i-1]));
			}
		}
		
		/*for (int i = 0; i < sort.length; i++) {
			for (int j = i + 1; j < sort.length; j++) {
				if (sort[i] > sort[j]) {
					int tmp = sort[j];
					sort[j] = sort[i];
					sort[i] = tmp;
				}
			}
		}*/
		
		return coe;
	}
}
