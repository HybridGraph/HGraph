package cn.edu.neu.termite.util.driver;

import org.apache.hadoop.util.ProgramDriver;

import cn.edu.neu.termite.util.data.DFGeneralTermite;
import cn.edu.neu.termite.util.data.DFPageRankTermite;
import cn.edu.neu.termite.util.data.DGPageRankBCBSP;
import cn.edu.neu.termite.util.data.DGPageRankTermite;
import cn.edu.neu.termite.util.data.DGSSSPTermite;
import cn.edu.neu.termite.util.data.DTDataAdd;
import cn.edu.neu.termite.util.data.DTEdgeList2AdjList;
import cn.edu.neu.termite.util.data.DTEdgeDelete;
import cn.edu.neu.termite.util.data.DTPageRankBCBSP2Termite;
import cn.edu.neu.termite.util.data.DTPageRankTermite2EdgeList;
import cn.edu.neu.termite.util.data.DTPageRankTermite2Giraph;
import cn.edu.neu.termite.util.data.DTPageRankTermite2Hama;
import cn.edu.neu.termite.util.data.DTPageRankTermite2Mocgraph;
import cn.edu.neu.termite.util.data.DTPageRankTermite2GraphLab;
import cn.edu.neu.termite.util.data.DTTermitePageRank2SSSP;
import cn.edu.neu.termite.util.data.EvaLocality;
import cn.edu.neu.termite.util.data.EvaVariance;

//import cn.edu.neu.termite.util.data.PageRankTermite2Hama;
//import cn.edu.neu.termite.util.data.SSSPTermite2Giraph;
//import cn.edu.neu.termite.util.data.SSSPTermite2Hama;
//import cn.edu.neu.termite.util.data.TermiteSSSP2PageRank;
//import cn.edu.neu.termite.util.data.Text2Sequence;

public class UtilDriver {
	
	public static void main(String argv[]){
	    int exitCode = -1;
	    ProgramDriver pgd = new ProgramDriver();
	    
	    try {
	    	pgd.addClass("livej", DFGeneralTermite.class, 
	    			"data format for livej");
	    	pgd.addClass("dgprTermite", DGPageRankTermite.class, 
	    			"data generation for pagerank used in Termite");
	    	pgd.addClass("dgprBCBSP", DGPageRankBCBSP.class, 
					"data generation for pagerank used in BCBSP");
	    	pgd.addClass("dgsssp", DGSSSPTermite.class, 
	    			"data generation for single source shortest path used in Termite");
	    	pgd.addClass("dtprBCBSP2Termite", DTPageRankBCBSP2Termite.class, 
	    			"data transformation for pagerank from BCBSP to Termite");
	    	pgd.addClass("dtprTermite2Giraph", DTPageRankTermite2Giraph.class, 
					"data transformation for pagerank from Termite to Giraph");
	    	pgd.addClass("dtprTermite2Mocgraph", DTPageRankTermite2Mocgraph.class, 
	    			"data transformation for pagerank from Termite to MOCgraph");
	    	pgd.addClass("dtprTermite2GraphLab", DTPageRankTermite2GraphLab.class, 
					"data transformation for pagerank from Termite to GraphLab");
	    	pgd.addClass("dtprTermite2EdgeList", DTPageRankTermite2EdgeList.class, 
					"data transformation for pagerank from Termite to Haloop");
	    	pgd.addClass("dtprTermite2Hama", DTPageRankTermite2Hama.class, 
	    			"data transformation for pagerank from Termite to Hama");
	    	pgd.addClass("dtTermitePageRank2SSSP", DTTermitePageRank2SSSP.class, 
				"data transformation from PageRank to FC-SSSP (Termite)");
	    	pgd.addClass("add", DTDataAdd.class, 
					"add edges");
	    	
	    	pgd.addClass("el2al", DTEdgeList2AdjList.class, 
					"transfer edge-list into adjacency-list");
	    	pgd.addClass("dfpr", DFPageRankTermite.class, 
				"data format for pagerank used in Termite");
	    	
	    	pgd.addClass("edel", DTEdgeDelete.class, 
				"delete edge outbound vertex id range");
	    	
	    	pgd.addClass("evaloc", EvaLocality.class, 
					"evaluate locality coefficient");
	    	pgd.addClass("evavar", EvaVariance.class, 
					"evaluate variance w.s.t. avg degree");
	    	
	    	/*pgd.addClass("pagerankTermite2Hama", PageRankTermite2Hama.class,
					"data format for pagerank from termite to hama");
	    	pgd.addClass("ssspTermite2Giraph", SSSPTermite2Giraph.class,
	    			"data format for sssp from termite to giraph");
	    	pgd.addClass("ssspTermite2Hama", SSSPTermite2Hama.class,
					"data format for sssp from termite to hama");
	    	pgd.addClass("text2seq", Text2Sequence.class,
					"data format from text to sequence.");
	    	pgd.addClass("termiteSSSP2PageRank", TermiteSSSP2PageRank.class,
					"data format for termite from sssp to pagerank");*/
	    	
	    	pgd.driver(argv);
	    	exitCode = 0;
	    } catch(Throwable e) {	    	
	    	e.printStackTrace();
	    }
	    
	    System.exit(exitCode);
	}
}
