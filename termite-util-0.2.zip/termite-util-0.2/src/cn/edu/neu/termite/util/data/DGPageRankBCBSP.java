package cn.edu.neu.termite.util.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Random;

/**
 * Data generator for PageRank algorithm used in BCBSP.
 * The output is a non-weight graph.
 * The input args includes:
 *   (1)#vertices
 *   (2)#base edges per vertex
 *   (3)#random edges per vertex
 *   (4)#output file
 * Data format: <code>srcId:DEFAULT_VERTEX_VALUE</code>\t<code>dstId1 dstId2 ...</code>
 * 
 * After generating, this program reports the following info.:
 * (1) size(MB);
 * (2) #vertices;
 * (3) #outgoing edges;
 * (4) avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2013.11.09
 */
public class DGPageRankBCBSP {
	// the total number of vertices
	public static int VERTEX_COUNT = 10;
	// the average number of outgoing edges for every vertex
	public static int EDGE_COUNT_BASE = 2;
	public static int EDGE_COUNT_RANDOM = 1;
	// the default value of vertex
	public static String DEFAULT_VERTEX_VALUE = "10.0";
	// the default value of edge-weight
	public static String DEFAULT_EDGE_WEIGHT = "0";
	// define the split flag
	public static String VERTEX_ID_VALUE_SPLIT = ":";
	public static String EDGE_ID_WEIGHT_SPLIT = ":";
	public static String VERTEX_EDGE_SPLIT = "\t";
	public static String EDGE_EDGE_SPLIT = " ";
	// the output path
	public static String OUTPUT_PATH = "/termite-rd-pr";
	// statics
	public static int STATIC_VERTEX = 0;
	public static int STATIC_EDGE = 0;
	
	public static void main(String[] args) {
		// check the input arguments
		if (args.length < 4) {
			StringBuffer sb = 
				new StringBuffer("input arguments of bcbsp-dg-pr:");
			sb.append("\n\t[1]"); sb.append("vertex: #vertices(int).");
			sb.append("\n\t[2]"); sb.append("edge-b: #base outgoing edges per vertex(int).");
			sb.append("\n\t[3]"); sb.append("edge-r: #random outgoing edges per vertex(int).");
			sb.append("\n\t[4]"); sb.append("output: absolute path of the output file.");
			
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			VERTEX_COUNT = Integer.valueOf(args[0]);
			EDGE_COUNT_BASE = Integer.valueOf(args[1]);
			EDGE_COUNT_RANDOM = Integer.valueOf(args[2]);
			OUTPUT_PATH = args[3];
		}
		
		Random rVertex = new Random();
		Random rVertexCount = new Random();
		File root = new File(OUTPUT_PATH);
		try{
			System.out.println("begin to generate the random graph, please wait...");
			FileWriter fw = new FileWriter(root);
			BufferedWriter bw = new BufferedWriter(fw);
			
			// generate the first record
			// define the number of outgoing edges per vertex
			int count = rVertexCount.nextInt(EDGE_COUNT_RANDOM) + EDGE_COUNT_BASE;
			StringBuffer sb = 
				new StringBuffer(Integer.toString(rVertex.nextInt(VERTEX_COUNT)));
			for (int j = 1; j < count; j++) {
				sb.append(EDGE_EDGE_SPLIT + rVertex.nextInt(VERTEX_COUNT));
			}
			bw.write(0 + VERTEX_ID_VALUE_SPLIT + DEFAULT_VERTEX_VALUE + VERTEX_EDGE_SPLIT 
					+ sb.toString());
			STATIC_VERTEX += 1;
			STATIC_EDGE += count;
			
			// generate the remaining records
			for (int i = 1; i < VERTEX_COUNT; i++) {
				count = rVertexCount.nextInt(EDGE_COUNT_RANDOM) + EDGE_COUNT_BASE;
				sb = new StringBuffer(Integer.toString(rVertex.nextInt(VERTEX_COUNT)));
				for (int j = 1; j < count; j++) {
					sb.append(EDGE_EDGE_SPLIT + rVertex.nextInt(VERTEX_COUNT));
				}
				bw.newLine();
				bw.write(i + VERTEX_ID_VALUE_SPLIT + DEFAULT_VERTEX_VALUE 
						+ VERTEX_EDGE_SPLIT + sb.toString());
				STATIC_VERTEX += 1;
				STATIC_EDGE += count;
			}
			bw.close();
			fw.close();
		}catch(Exception e){
			System.out.println(e);
		}	
		
		System.out.println("generate data successfully!");
		System.out.println("statics information is as follws:");
		System.out.println("size: " + root.length()/(float)(1024 * 1024) + " MB");
		System.out.println("#vertices: " + STATIC_VERTEX);
		System.out.println("#outgoing edges: " + STATIC_EDGE);
		System.out.println("avg outgoing degree: " + STATIC_EDGE/(float)STATIC_VERTEX);
	}
}
