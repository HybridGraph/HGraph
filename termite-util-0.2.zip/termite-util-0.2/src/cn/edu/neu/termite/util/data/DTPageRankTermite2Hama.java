package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class DTPageRankTermite2Hama {
	
	private static String inFileName = "/root/workspace3.3.2/data/termite-random-pagerank.txt";
	private static String outFileName = "/root/workspace3.3.2/data/hama-random-pagerank.txt";
	
	private static File inputFile;
	private static File outputFile;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	public static void main(String[] args) {
		
		if (args.length < 2) {
			StringBuffer sb = new StringBuffer("The transformation(PageRank) from Termite to Hama must be given the following arguments(2):");
			sb.append("\n\t[1]"); sb.append("Input  File Name: the name of input file used for Termite(including the absolute path).");
			sb.append("\n\t[2]"); sb.append("Output File Name: the name of output file used for Hama(including the absolute path).");
			
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = args[1];
		}
		
		System.out.println("Begin to transform the raw graph from Termite to Hama, please wait...");
		
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			String context = null;
			String[] firstSplit = null, secondSplit = null;
			StringBuffer sb = new StringBuffer();
			int edgeLength = 0;
			while ((context = BR.readLine()) != null) {
				firstSplit = context.split("\t");
				secondSplit = firstSplit[1].split(":");
				edgeLength = secondSplit.length;
				
				sb.setLength(0); sb.append(firstSplit[0]); sb.append("\t");
				sb.append(secondSplit[0]); sb.append(":"); sb.append("0");
				for (int index  = 1; index < edgeLength; index++) {
					sb.append("\t"); sb.append(secondSplit[index]);
					sb.append(":"); sb.append("0");
				}
				
				BW.write(sb.toString());
				BW.newLine();
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("Transform successfully!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
