package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.SequenceFile.Writer;

public class Text2Sequence {
	
	static Path inPath = new Path("/root/workspace3.3.2/data/termite-random-sssp-50wan.txt");
	static Path outPath = inPath.getParent();
	static String delimiter;
	static Configuration conf;
	static FileSystem sourceFs;
	static FileSystem destFs;
	
	public static void main(String[] args) throws IOException {
		
		if (args.length < 1) {
			System.out.println("Please give the name of textFile(including the absolute path).");
			System.exit(-1);
		} else {
			inPath = new Path(args[0]);
			outPath = inPath.getParent();
		}
		
		System.out.println("Begin to transform the source file from text to sequence, please wait...");
		
		conf = new Configuration();
	    sourceFs = inPath.getFileSystem(conf);
	    destFs = outPath.getFileSystem(conf);
	    
	    Path out = new Path(outPath, inPath.getName() + ".seq");
	    Writer writer = new Writer(destFs, conf, out, Text.class, Text.class);
	    
	    BufferedReader br = null;
	    String[] result;
	    try {
	    	br = new BufferedReader(new InputStreamReader(sourceFs.open(inPath)));
	        String line;
	        while ((line = br.readLine()) != null) {
	        	result = line.split("\t");
	        	writer.append(new Text(result[0]), new Text(result[1]));
	        }
	        
	        System.out.println("Transform successfully!");
	    } finally {
	    	if (br != null) {
	    		br.close();
	        }
	    	writer.close();
	    }
	}
}
