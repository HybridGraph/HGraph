package cn.edu.neu.termite.util.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Random;

/**
 * Data generator for the single source shortest path computation algorithm 
 * used in Termite.
 * The output is a weight graph.
 * The input args includes:
 *   (1)#vertices
 *   (2)#base edges per vertex
 *   (3)#random edges per vertex
 *   (4)#output file
 * Data format: <code>srcId</code>\t<code>dstId1:weight1:dstId2:weight2:...</code>
 * 
 * After generating, this program reports the following info.:
 * (1) size(MB);
 * (2) #vertices;
 * (3) #outgoing edges;
 * (4) weight-seed;
 * (5) avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2013.11.09
 */
public class DGSSSPTermite {
	// the total number of vertices
	public static int VERTEX_COUNT = 10;
	// the average number of outgoing edges for every vertex
	public static int EDGE_COUNT_BASE = 10;
	public static int EDGE_COUNT_RANDOM = 8;
	// the default value of vertex
	public static String DEFAULT_VERTEX_VALUE = Integer.toString(Integer.MAX_VALUE);
	// the default value of edge-weight
	public static String DEFAULT_EDGE_WEIGHT = "1";
	// define the split flag
	public static String VERTEX_ID_VALUE_SPLIT = ":";
	public static String EDGE_ID_WEIGHT_SPLIT = ":";
	public static String VERTEX_EDGE_SPLIT = "\t";
	public static String EDGE_EDGE_SPLIT = ":";
	// the output path
	public static String OUTPUT_PATH = "/termite-rd-sssp";
	// statics
	public static int STATIC_VERTEX = 0;
	public static int STATIC_EDGE = 0;
	
	public static void main(String[] args) {
		// check input argements
		if (args.length < 4) {
			StringBuffer sb = 
				new StringBuffer("input arguments of termite-dg-sssp:");
			sb.append("\n\t[1]"); sb.append("vertex: #vertices(int).");
			sb.append("\n\t[2]"); sb.append("edge-b: #base outgoing edges per vertex(int).");
			sb.append("\n\t[3]"); sb.append("edge-r: #random outgoing edges per vertex(int).");
			sb.append("\n\t[4]"); sb.append("output: absolute path of the output file.");
			
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			VERTEX_COUNT = Integer.valueOf(args[0]);
			EDGE_COUNT_BASE = Integer.valueOf(args[1]);
			EDGE_COUNT_RANDOM = Integer.valueOf(args[2]);
			OUTPUT_PATH = args[3];
		}

		Random rVertex = new Random();
		Random rVertexCount = new Random();
		Random rWeight = new Random();
		File root = new File(OUTPUT_PATH);
		try{
			System.out.println("begin to generate the random graph, please wait...");
			FileWriter fw = new FileWriter(root);
			BufferedWriter bw = new BufferedWriter(fw);
			
			// generate the first record
			// generate the random number of outgoing edges for the vertex
			int count = rVertexCount.nextInt(EDGE_COUNT_RANDOM) + EDGE_COUNT_BASE;
			StringBuffer sb = new StringBuffer(rVertex.nextInt(VERTEX_COUNT) 
					+ EDGE_ID_WEIGHT_SPLIT + (rWeight.nextDouble()));
			for (int j = 1; j < count; j++) {
				sb.append(EDGE_EDGE_SPLIT + rVertex.nextInt(VERTEX_COUNT) 
						+ EDGE_ID_WEIGHT_SPLIT + (rWeight.nextDouble()));
			}
			bw.write(0 + VERTEX_EDGE_SPLIT + sb.toString());
			STATIC_VERTEX += 1;
			STATIC_EDGE += count;
			
			for (int i = 1; i < VERTEX_COUNT; i++) {
				count = rVertexCount.nextInt(EDGE_COUNT_RANDOM) + EDGE_COUNT_BASE;
				sb = new StringBuffer(rVertex.nextInt(VERTEX_COUNT) 
						+ EDGE_ID_WEIGHT_SPLIT + (rWeight.nextDouble()));
				for (int j = 1; j < count; j++) {
					sb.append(EDGE_EDGE_SPLIT + rVertex.nextInt(VERTEX_COUNT) 
							+ EDGE_ID_WEIGHT_SPLIT + (rWeight.nextDouble()));
				}
				bw.newLine();
				bw.write(i + VERTEX_EDGE_SPLIT + sb.toString());
				STATIC_VERTEX += 1;
				STATIC_EDGE += count;
			}
			bw.close();
			fw.close();
		}catch(Exception e){
			System.out.println(e);
		}	
		
		System.out.println("generate data successfully!");
		System.out.println("statics information is as follws:");
		System.out.println("size: " + root.length()/(float)(1024 * 1024) + " MB");
		System.out.println("#vertices: " + STATIC_VERTEX);
		System.out.println("#outgoing edges: " + STATIC_EDGE);
		System.out.println("avg outgoing degree: " + STATIC_EDGE/(float)STATIC_VERTEX);
	}
}