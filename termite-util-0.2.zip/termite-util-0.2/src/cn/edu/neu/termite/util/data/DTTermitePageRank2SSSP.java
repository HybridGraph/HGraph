package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;

/**
 * Transform data used in Termite from PageRank into SSSP (adding weight for each edge).
 * The graph data are used for FCSSSP algorithm, a weight graph.
 * 
 * PageRank format: <code>id</code>\t<code>dstId1:dstId2:...</code>
 * FCSSSP format: <code>id</code>\t<code>dstId1</code>:<code>weight1</code>...
 * For instance: "0	1:2" --> "0	1:0.23:2:0.45"
 * 
 * After transformation, this program reports the following info.:
 * (1) size;
 * (2) #output vertices;
 * (3) #output edges;
 * (4) #output avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2016.09.22
 */
public class DTTermitePageRank2SSSP {
	
	private static String inFileName = "/termite-pr";
	private static String outFileName = "/termite-fcsssp";
	
	private static File inputFile;
	private static File outputFile;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	private static int VertexCounter = 0;
	private static int EdgeCounter = 0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length < 1) {
			System.out.println("input arguments of data transform: " +
					"<input file>");
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-fcsssp";
		}
		
		System.out.println("begin to transform data " +
				"from PageRank to FC-SSSP, please wait...");
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			Random rd = new Random();
			String context = null;
			String[] firstSplit = null, secondSplit = null;
			StringBuffer sb = new StringBuffer();
			int edgeLength = 0;
			while ((context = BR.readLine()) != null) {
				firstSplit = context.split("\t");
				if (firstSplit.length == 1) {
					secondSplit = new String[]{firstSplit[0]};
				} else {
					secondSplit = firstSplit[1].split(":");
				}
				edgeLength = secondSplit.length;
				
				sb.setLength(0); //begin to transform one record
				sb.append(firstSplit[0]); //vertex id
				sb.append("\t"); //begin to add edges
				sb.append(secondSplit[0]); //add first edge & weight
				sb.append(":");
				sb.append(Double.toString(rd.nextDouble()));
				
				for (int index  = 1; index < edgeLength; index++) {
					sb.append(":");
					sb.append(secondSplit[index]);
					sb.append(":");
					sb.append(Double.toString(rd.nextDouble()));
				}
				
				BW.write(sb.toString());
				BW.newLine();
				VertexCounter++;
				EdgeCounter += edgeLength;
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("transform successfully!");
			System.out.println("size: "
					+ outputFile.length()/(float)(1024 * 1024) + " MB");
			System.out.println("#vertices=" + VertexCounter);
			System.out.println("#edges=" + EdgeCounter);
			System.out.println("avg outgoing degree=" 
					+ EdgeCounter/(float)VertexCounter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
