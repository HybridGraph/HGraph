package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;

public class DTDataAdd {
	
	private static String inFileName = "/root/workspace3.3.2/data/termite-random-pagerank.txt";
	private static String outFileName = "/root/workspace3.3.2/data/termite-random-pagerank-add.txt";
	
	private static File inputFile;
	private static File outputFile;
	private static int add;
	private static int min, max;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	public static void main(String[] args) {
		
		if (args.length < 2) {
			StringBuffer sb = new StringBuffer("The format (add edge) must be given the following arguments(4):");
			sb.append("\n\t[1]"); sb.append("Input  File Name.");
			sb.append("\n\t[2]"); sb.append("Add Number.");
			sb.append("\n\t[3]"); sb.append("Min Vertex Id.");
			sb.append("\n\t[4]"); sb.append("Max Vertex Id.");
			
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-add-" + args[1];
			add = Integer.valueOf(args[1]);
			min = Integer.valueOf(args[2]);
			max = Integer.valueOf(args[3]);
		}
		System.out.println("Begin to add edges to the raw graph, please wait...");
		
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			Random rd = new Random();
			String context = null;
			StringBuffer sb = new StringBuffer();
			while ((context = BR.readLine()) != null) {
				sb.setLength(0);
				for (int index  = 0; index < add; index++) {
					sb.append(":");
					int id = rd.nextInt(max);
					id = id<min? (id+min):id;
					sb.append(id);
				}
				
				BW.write(context + sb.toString());
				BW.newLine();
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("Format successfully!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
