package cn.edu.neu.termite.util.test;

import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

public class RandomGenerateTest {
	
	public static void main(String[] args) {
		/*Random rd = new Random();
		int enlarge = 105;
		int verNum = 5102631;
		int total = 105896555;
		
		long start = System.currentTimeMillis();
		for (int i = 0; i < verNum; i++) {
			ArrayList<Integer> edges = new ArrayList<Integer>();
			for (int j = 0; j < enlarge; j++) {
				edges.add(rd.nextInt(total));
			}
		}
		System.out.println("cost:" + (System.currentTimeMillis()-start)/(float)1000.0 + "s");*/
		
		String line = "haha:wuwu";
		StringTokenizer tokenizer = new StringTokenizer(line, ":");
		while (tokenizer.hasMoreTokens())
			System.out.println(tokenizer.nextToken());
		System.out.println(Math.ceil(12.000));
	}
}
