package cn.edu.neu.termite.util.data;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * Format source data to ensure that all records(vertices) 
 * are consecutive numbered. For empty records, 
 * it will be filled up by records with consecutive numbers 
 * and the added vertex has only one outbound neighbor: itself.
 * 
 * For the record whose outgoing edges is 0, one neighbor (itself) 
 * will be added to its outgoing edge list.
 * 
 * Note that the error record will be displayed in console 
 * if the current vertex id is less than the previous one.
 * And, it will not be written into the output file.
 * 
 * After formatting, this program reports the following info.:
 * (1) #initial records;
 * (2) #additional records;
 * (3) #skip error records;
 * (4) #total vertices;
 * (5) #total edges;
 * (6) avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2013.11.10
 */
public class DFPageRankTermite {
	
	private static String inFileName = "/input";
	private static String outFileName = "/input-format";
	
	private static File inputFile;
	private static File outputFile;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	private static int MaxVertId = 0;
	/** # of input records */
	private static int InputRecordCounter = 0;
	private static int AddVertCounter = 0;
	private static int AddEdgeCounter = 0;
	private static int VertCounter = 0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length < 1) {
			StringBuffer sb = 
				new StringBuffer("Usage of Consecutive Check: <input file> <maxVertId>");
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-consecutive";
			MaxVertId = Integer.valueOf(args[1]);
		}
		
		System.out.println("begin to format data (consecutive check), please wait...");
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			String context = null;
			String[] kv = null;
			int begin = -1, id = 0; 
			StringBuffer sb = new StringBuffer();
			while ((context = BR.readLine()) != null) {
				sb.setLength(0);
				kv= context.split("\t");
				InputRecordCounter++;
				VertCounter++;
				
				id = Integer.valueOf(kv[0]);
				if (begin < 0) {
					begin = id;
				} else if ((begin+1) < id) {
					while ((begin+1) < id) {
						sb.setLength(0);
						begin++;
						sb.append(begin);
						sb.append("\t");
						sb.append(begin);
						BW.write(sb.toString());
						BW.newLine(); // add the empty records
						AddVertCounter++;
						AddEdgeCounter++;
						VertCounter++;
					}
				} else if ((begin+1) > id) {
					System.out.println("Error: [previous]=" + begin 
							+ "\t [current]=" + id);
					System.exit(-1); // display the error record and skip it
				}
				begin = id;
				BW.write(context);
				BW.newLine(); // save the original record
			}
			
			for (begin = begin+1; begin <= MaxVertId; begin++) {
				sb.setLength(0);
				sb.append(begin);
				sb.append("\t");
				sb.append(begin);
				AddVertCounter++;
				AddEdgeCounter++;
				VertCounter++;
				
				BW.write(sb.toString());
				BW.newLine(); // save the original record
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("done successfully!");
			System.out.println("input records: " + InputRecordCounter);
			System.out.println("added vertices: " + AddVertCounter);
			System.out.println("added edges: " + AddEdgeCounter);
			System.out.println("total vertices: " + VertCounter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}