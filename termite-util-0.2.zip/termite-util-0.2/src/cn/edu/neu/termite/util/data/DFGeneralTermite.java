package cn.edu.neu.termite.util.data;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;

/**
 * 去掉出边中的0，确保所有的顶点均有出边（无出边的，补充为源顶点）
 * 
 * After formatting, this program reports the following info.:
 * (1) #initial records;
 * (2) #additional records;
 * (3) #skip error records;
 * (4) #total vertices;
 * (5) #total edges;
 * (6) avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2013.11.10
 */
public class DFGeneralTermite {
	
	private static String inFileName = "/input";
	private static String outFileName = "/input-format";
	
	private static File inputFile;
	private static File outputFile;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	private static int InitCounter = 0;
	private static int AddCounter = 0;
	private static int SkipCounter = 0;
	private static int VertexCounter = 0;
	private static long EdgeCounter = 0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length < 1) {
			StringBuffer sb = 
				new StringBuffer("input arguments of data format: <input file>");
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-format";
		}
		
		System.out.println("begin to format data, please wait...");
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			String context = null;
			String[] firstSplit = null;
			String[] edges = null;
			int begin = -1, id = 0, edgeCounter = 0; 
			while ((context = BR.readLine()) != null) {
				firstSplit = context.split("\t");
				InitCounter++;
				
				id = Integer.valueOf(firstSplit[0]);
				edges = firstSplit[1].split(":");
				StringBuffer sb = new StringBuffer();
				HashMap<Integer, Integer> cache = new HashMap<Integer, Integer>();
				/*if (id == 59820) {
					System.out.println(context);
				}*/
				for (int i = 0; i < edges.length; i++) {
					int edge = Integer.valueOf(edges[i]);
					/*if (edge == 0 && edges.length > 1 && i==0) {
						continue;
					}*/
					
					cache.put(edge, edge);
				}
				
				if (cache.containsKey(id)) {
					cache.remove(id);
				}
				
				if (cache.size() > 0) {
					int len = cache.size(), i = 0;
					for (int edge: cache.keySet()) {
						sb.append(edge);
						i++;
						if (i < len) {
							sb.append(":");
						}
						edgeCounter++;
					}
				} else {
					sb.append(Integer.toString(id));
					edgeCounter++;
				}
				
				BW.write(id + "\t" + sb.toString());
				BW.newLine(); // save the original record
			}
			EdgeCounter += edgeCounter;
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			VertexCounter = InitCounter + AddCounter - SkipCounter;
			System.out.println("transform successfully!");
			System.out.println("init records=" + InitCounter);
			System.out.println("skip records=" + SkipCounter);
			System.out.println("#output vertices=" + VertexCounter);
			System.out.println("#output edges=" + EdgeCounter);
			System.out.println("output avg outgoing degree=" + EdgeCounter/(float)VertexCounter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}