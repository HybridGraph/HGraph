package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;

public class DTEdgeDelete {
	
	private static String inFileName = "/root/workspace3.3.2/data/termite-random-pagerank.txt";
	private static String outFileName = "/root/workspace3.3.2/data/termite-random-pagerank-delete.txt";
	
	private static File inputFile;
	private static File outputFile;
	private static int del = 0;
	private static int min, max;
	private static long eNum = 0L;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	public static void main(String[] args) {
		
		if (args.length < 3) {
			StringBuffer sb = new StringBuffer("The format (delete edge) must be given the following arguments(4):");
			sb.append("\n\t[1]"); sb.append("Input  File Name.");
			sb.append("\n\t[2]"); sb.append("Min Vertex Id.");
			sb.append("\n\t[3]"); sb.append("Max Vertex Id.");
			
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-delete";
			min = Integer.valueOf(args[1]);
			max = Integer.valueOf(args[2]);
		}
		System.out.println("Begin to check edges to the raw graph, please wait...");
		
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			String context = null;
			String[] first = null, second = null;
			StringBuffer sb = new StringBuffer();
			int eid = 0;
			while ((context = BR.readLine()) != null) {
				first = context.split("\t");
				second = first[1].split(":");
				
				sb.setLength(0); 
				sb.append(first[0]); 
				sb.append("\t"); sb.append(second[0]);
				eNum++;
				for (int i = 1; i < second.length; i++) {
					eid = Integer.valueOf(second[i]);
					if (eid <= max && eid >= min) {
						sb.append(":");
						sb.append(second[i]);
						eNum++;
					} else {
						del++;
					}
				}
				
				BW.write(sb.toString());
				BW.newLine();
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("Format successfully!");
			System.out.println("now, #edges:" + eNum);
			System.out.println("has deleted, #edges:" + del);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
