package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class DTEdgeList2AdjList {
	
	private static String inFileName = "/root/workspace3.3.2/data/edge";
	private static String outFileName = "/root/workspace3.3.2/data/edge-list";
	
	private static File inputFile;
	private static File outputFile;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	public static void main(String[] args) {
		
		if (args.length < 1) {
			StringBuffer sb = 
				new StringBuffer("Usage of Transferring Edge-List to Adjacency-List");
			sb.append("\n\t[1]"); sb.append("Input  File Name.");
			
			System.out.println(sb.toString());
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-list";
		}
		System.out.println("begin to transfer edge-list into adjacency-list, please wait...");
		
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
			int vId = -1, key = 0, value = 0, eIdx = 0;
			long vNum = 0L, eNum = 0L, errNum = 0L, prog = 0L;
			
			String context = null;
			String[] kv = new String[2];
			StringBuffer sb = new StringBuffer();
			sb.setLength(0);
			while ((context = BR.readLine()) != null) {
				if (context.startsWith("#")) {
					continue;
				}
				
				prog++;
				if (prog%10000000 == 0) {
					System.out.println("line " + prog);
				}
				
				kv = context.split(" ");
				if (kv.length != 2) {
					errNum++;
					System.err.println(context);
					continue;
				}
				
				key = Integer.valueOf(kv[0]);
				value = Integer.valueOf(kv[1]);
				min = Math.min(min, key);
				max = Math.max(max, key);
				min = Math.min(min, value);
				max = Math.max(max, value);
				
				if (vId < key) {
					//save an adjacency list
					if (sb.length() > 0) {
						BW.write(sb.toString());
						BW.newLine();
						sb.setLength(0);
					}
					
					//initialize a new adjacency list
					vId = key;
					vNum++;
					sb.append(kv[0]);
					sb.append("\t");
					eIdx = 0;
				}
				
				if (eIdx > 0) {
					sb.append(":");
				}
				sb.append(kv[1]);
				eIdx++;
				eNum++;
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("done successfully!");
			System.out.println("min id:" + min);
			System.out.println("max id:" + max);
			System.out.println("#vertices:" + vNum);
			System.out.println("#edges:" + eNum);
			System.out.println("#errors:" + errNum);
			System.out.println("avg. out-degree:" + (eNum/(float)vNum));
			System.out.println("size:" + outputFile.length()/(float)(1024 * 1024) + " MB");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
