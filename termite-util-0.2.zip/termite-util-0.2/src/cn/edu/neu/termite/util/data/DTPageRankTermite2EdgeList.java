package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * Transform data from Termite format (adjacency list) into edge list format (used in Haloop and PEGASUS).
 * The input graph is non-weight, and can be used for running PageRank, WCC, LPA, etc.
 * 
 * input format: <code>srcId</code>\t<code>dstId1:dstId2:...</code>
 * output format: <code>srcId</code>\t<code>dstId1</code>
 *                <code>srcId</code>\t<code>dstId2</code>
 *                (and)
 *                <code>dstId1</code>\t<code>srcId1</code>
 *                <code>dstId2</code>\t<code>srcId2</code>
 *                ...
 * 
 * For instance: "0	1:2" --> "0	1"
 *                           "0	2"
 *                           (and)
 *                           "1 0"
 *                           "2 0"
 * 
 * After transformation, this program reports the following info.:
 * (1) size;
 * (2) #output vertices;
 * (3) #output edges;
 * (4) #output avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2014.10.24
 */
public class DTPageRankTermite2EdgeList {
	
	private static String inFileName = "/termite-rd-pr";
	private static String outFileNameSrcDst = "/edgelist_src_dst";
	private static String outFileNameDstSrc = "/edgelist_dst_src";
	
	private static File inputFile;
	private static File outputFileSrcDst;
	private static File outputFileDstSrc;
	private static FileReader fr;
	private static FileWriter fwSrcDst;
	private static FileWriter fwDstSrc;
	private static BufferedReader br;
	private static BufferedWriter bwSrcDst;
	private static BufferedWriter bwDstSrc;
	
	private static boolean reverse = false;
	private static boolean add = false;
	
	private static int VertexCounter = 0;
	private static int EdgeCounter = 0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length < 3) {
			System.out.println("input arguments of data transform: <input file> <true or false: reverse>");
			System.out.println("<false/true>: output src_dst/src_dst&dst_src edge list");
			System.out.println("<false/true>: ignore/add one edge if out-deg=0");
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileNameSrcDst = inFileName + "_src_dst";
			outFileNameDstSrc = inFileName + "_dst_src";
			reverse = Boolean.parseBoolean(args[1]);
			add = Boolean.parseBoolean(args[2]);
		}
		
		System.out.println("begin to transform data from adjacency list to edge list, please wait...");
		try {
			inputFile = new File(inFileName);
			fr = new FileReader(inputFile);
			br = new BufferedReader(fr, 65536);
			outputFileSrcDst = new File(outFileNameSrcDst);
			fwSrcDst = new FileWriter(outputFileSrcDst);
			bwSrcDst = new BufferedWriter(fwSrcDst, 65536);
			
			if (reverse) {
				outputFileDstSrc = new File(outFileNameDstSrc);
				fwDstSrc = new FileWriter(outputFileDstSrc);
				bwDstSrc = new BufferedWriter(fwDstSrc, 65536);
			}
			
			String context = null;
			String[] firstSplit = null, secondSplit = null;
			StringBuffer sb = new StringBuffer();
			int edgeLength = 0;
			while ((context = br.readLine()) != null) {
				firstSplit = context.split("\t");
				if (firstSplit.length == 1) {
					if (!add) {
						VertexCounter++;
						continue;
					} else {
						context = firstSplit + "\t" + firstSplit;
						firstSplit = context.split("\t");
					}
				}
				secondSplit = firstSplit[1].split(":");
				edgeLength = secondSplit.length;
				VertexCounter++;
				EdgeCounter += edgeLength;
				
				sb.setLength(0); // begin to transform one record (src_dst)
				sb.append(firstSplit[0]);
				sb.append("\t"); sb.append(secondSplit[0]); // first edge
				for (int index  = 1; index < edgeLength; index++) {
					sb.append("\n");
					sb.append(firstSplit[0]); sb.append("\t"); // other edges
					sb.append(secondSplit[index]);
				}
				bwSrcDst.write(sb.toString());
				bwSrcDst.newLine();
				
				if(!reverse) {
					continue;
				}
				sb.setLength(0); // begin to transform one record (dst_src)
				sb.append(secondSplit[0]);
				sb.append("\t"); sb.append(firstSplit[0]); // first edge
				for (int index  = 1; index < edgeLength; index++) {
					sb.append("\n");
					sb.append(secondSplit[index]); sb.append("\t"); // other edges
					sb.append(firstSplit[0]);
				}
				bwDstSrc.write(sb.toString());
				bwDstSrc.newLine();
			}
			
			br.close();
			fr.close();
			bwSrcDst.close();
			fwSrcDst.close();
			
			if (reverse) {
				bwDstSrc.close();
				fwDstSrc.close();
			}
			System.out.println("transform successfully!");
			System.out.println("src_dst file size: " + outputFileSrcDst.length()/(float)(1024 * 1024) + " MB");
			if (reverse) {
				System.out.println("dst_src file size: " + outputFileDstSrc.length()/(float)(1024 * 1024) + " MB");
			}
			System.out.println("#vertices=" + VertexCounter);
			System.out.println("#edges=" + EdgeCounter);
			System.out.println("avg outgoing degree=" + EdgeCounter/(float)VertexCounter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
