package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class EvaVariance {
	
	private static String inFileName = "/termite-rd-pr";
	
	private static File inputFile;
	private static FileReader fr;
	private static BufferedReader br;
	
	private static int VertexCounter = 0;
	private static int EdgeCounter = 0;
	private static double AVG = 0.0;
	private static double VAR = 0.0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length != 1) {
			System.out.println("input arguments of evaluating variance: <input file>");
			System.exit(-1);
		} else {
			inFileName = args[0];
		}
		
		System.out.println("begin to compute average degree, please wait...");
		try {
			inputFile = new File(inFileName);
			fr = new FileReader(inputFile);
			br = new BufferedReader(fr, 65536);
			
			String context = null;
			String[] firstSplit = null, secondSplit = null;
			int edgeLength = 0;
			while ((context = br.readLine()) != null) {
				firstSplit = context.split("\t");
				secondSplit = firstSplit[1].split(":");
				edgeLength = secondSplit.length;
				VertexCounter++;
				EdgeCounter += edgeLength;
			}
			br.close();
			fr.close();
			
			AVG = (double)EdgeCounter / (double)VertexCounter;
			System.out.println("begin to evaluate variance, please wait...");
			fr = new FileReader(inputFile);
			br = new BufferedReader(fr, 65536);
			double sum = 0.0;
			while ((context = br.readLine()) != null) {
				firstSplit = context.split("\t");
				secondSplit = firstSplit[1].split(":");
				edgeLength = secondSplit.length;
				sum += Math.pow(edgeLength-AVG, 2);
			}
			VAR = sum / VertexCounter;
			
			System.out.println("evaluation is done successfully!");
			System.out.println("#vertices=" + VertexCounter);
			System.out.println("#edges=" + EdgeCounter);
			System.out.println("avgerage degree=" + AVG);
			System.out.println("variance=" + VAR);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
