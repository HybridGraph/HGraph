package cn.edu.neu.termite.util.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * Transform data from Termite format into Giraph format.
 * The graph data are used for PageRank algorithm, a non-weight graph.
 * 
 * Termite format: <code>id</code>\t<code>dstId1:dstId2:...</code>
 * Giraph format: <code>[id,value,[[dstId1],[dstId2],...]]</code>
 * For instance: "0	1:2" --> "[0,10,[[1],[2]]]"
 * 
 * After transformation, this program reports the following info.:
 * (1) size;
 * (2) #output vertices;
 * (3) #output edges;
 * (4) #output avg outgoing degree;
 * 
 * @author Zhigang Wang
 * @time 2013.11.10
 */
public class DTPageRankTermite2Giraph {
	
	private static String inFileName = "/termite-rd-pr";
	private static String outFileName = "/termite-rd-pr-giraph";
	
	private static String DEFAULT_VERTEX_VALUE = "10";
	
	private static File inputFile;
	private static File outputFile;
	private static FileReader FR;
	private static FileWriter FW;
	private static BufferedReader BR;
	private static BufferedWriter BW;
	
	private static int VertexCounter = 0;
	private static int EdgeCounter = 0;
	
	public static void main(String[] args) {
		// check input arguments
		if (args.length < 1) {
			System.out.println("input arguments of data transform: <input file>");
			System.exit(-1);
		} else {
			inFileName = args[0];
			outFileName = inFileName + "-giraph";
		}
		
		System.out.println("begin to transform data from Termite to Giraph, please wait...");
		try {
			inputFile = new File(inFileName);
			outputFile = new File(outFileName);
			FR = new FileReader(inputFile);
			FW = new FileWriter(outputFile);
			BR = new BufferedReader(FR, 65536);
			BW = new BufferedWriter(FW, 65536);
			
			String context = null;
			String[] firstSplit = null, secondSplit = null;
			StringBuffer sb = new StringBuffer();
			int edgeLength = 0;
			while ((context = BR.readLine()) != null) {
				firstSplit = context.split("\t");
				if (firstSplit.length == 1) {
					secondSplit = new String[]{firstSplit[0]};
				} else {
					secondSplit = firstSplit[1].split(":");
				}
				edgeLength = secondSplit.length;
				
				sb.setLength(0); sb.append("["); // begin to transform one record
				sb.append(firstSplit[0]); sb.append(",");
				sb.append(DEFAULT_VERTEX_VALUE); sb.append(",");
				sb.append("["); // begin to add edges
				sb.append("["); sb.append(secondSplit[0]); sb.append("]"); // add first edge
				
				for (int index  = 1; index < edgeLength; index++) {
					sb.append(",");
					sb.append("["); sb.append(secondSplit[index]); sb.append("]");
				}
				
				sb.append("]"); // end adding edges
				sb.append("]"); // end transforming one record
				
				BW.write(sb.toString());
				BW.newLine();
				VertexCounter++;
				EdgeCounter += edgeLength;
			}
			
			BR.close();
			FR.close();
			BW.close();
			FW.close();
			System.out.println("transform successfully!");
			System.out.println("size: " + outputFile.length()/(float)(1024 * 1024) + " MB");
			System.out.println("#vertices=" + VertexCounter);
			System.out.println("#edges=" + EdgeCounter);
			System.out.println("avg outgoing degree=" + EdgeCounter/(float)VertexCounter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
